/* MIT License
 *
 * Copyright (C) 2020 Klarälvdalens Datakonsult AB, a KDAB Group company, info@kdab.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * */

#ifndef GRPROJECTTREEMODEL_H
#define GRPROJECTTREEMODEL_H

class GrTreeNode;
#include <QAbstractItemModel>
#include <QMap>

#include <grshared.h>
#include <grasset.h>

using AssetType = GrShared::AssetTypes;

class GrProjectTreeModel : public QAbstractItemModel
{
    Q_OBJECT

public:
    explicit GrProjectTreeModel(QMap<AssetType, QVector<GrAsset*>> groupTypes, QObject *parent = nullptr);

    // Basic functionality:
    QModelIndex index(int row, int column,
                      const QModelIndex &parent = QModelIndex()) const override;
    QModelIndex parent(const QModelIndex &index) const override;

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;

    // manipulations
    void setAssets(QMap<AssetType, QVector<GrAsset*>> groupTypes); // rebuilds tree compeletely
    void insertProject(GrAsset* asset); // single row insert

private:
    QMap<AssetType, QVector<GrAsset*>> m_grouptypes;
    QList<AssetType> m_keys;
};

#endif // GRPROJECTTREEMODEL_H
